#include <pthread.h>
#include <stdio.h>
#include <semaphore.h>
#include <unistd.h>

void *fun1();
void *fun2();

int shared = 1; // shared variable
sem_t s; // semaphore variable

int main() {
    sem_init(&s, 0, 1); // initialize semaphore (initial value 1)

    pthread_t thread1, thread2;

    // create threads
    pthread_create(&thread1, NULL, fun1, NULL);
    pthread_create(&thread2, NULL, fun2, NULL);

    // wait for threads to finish
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    printf("Final value of shared is %d\n", shared); // print the final value of the shared variable

    sem_destroy(&s); // destroy the semaphore
    return 0;
}

void *fun1() {
    int x;

    sem_wait(&s); // perform wait operation on the semaphore
    x = shared; // read the value of the shared variable
    printf("Thread1 reads the value as %d\n", x);

    x++; // increment the local value
    printf("Local updation by Thread1: %d\n", x);

    sleep(1); // simulate preemption

    shared = x; // update the value of the shared variable
    printf("Value of shared variable updated by Thread1 is: %d\n", shared);

    sem_post(&s); // perform post operation on the semaphore
}

void *fun2() {
    int y;

    sem_wait(&s); // perform wait operation on the semaphore
    y = shared; // read the value of the shared variable
    printf("Thread2 reads the value as %d\n", y);

    y--; // decrement the local value
    printf("Local updation by Thread2: %d\n", y);

    sleep(1); // simulate preemption

    shared = y; // update the value of the shared variable
    printf("Value of shared variable updated by Thread2 is: %d\n", shared);

    sem_post(&s); // perform post operation on the semaphore
}
