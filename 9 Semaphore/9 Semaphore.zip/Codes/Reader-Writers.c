#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

sem_t writerSem, readerSem;
int readerCount = 0;
int sharedData = 0;

void* writer(void* arg) {
    int id = *(int*)arg;
    sem_wait(&writerSem);  // Writer lock
    sharedData++;          // Writing
    printf("Writer %d updated shared data to %d\n", id, sharedData);
    sem_post(&writerSem);  // Writer unlock
    return NULL;
}

void* reader(void* arg) {
    int id = *(int*)arg;
    sem_wait(&readerSem);  // Synchronize readerCount
    readerCount++;
    if (readerCount == 1) {
        sem_wait(&writerSem);  // Block writer if this is the first reader
    }
    sem_post(&readerSem);

    // Reading
    printf("Reader %d read shared data: %d\n", id, sharedData);

    sem_wait(&readerSem);  // Synchronize readerCount
    readerCount--;
    if (readerCount == 0) {
        sem_post(&writerSem);  // Unblock writer if this is the last reader
    }
    sem_post(&readerSem);
    return NULL;
}

int main() {
    pthread_t writers[3], readers[5];
    int writerIds[3] = {1, 2, 3};
    int readerIds[5] = {1, 2, 3, 4, 5};

    sem_init(&writerSem, 0, 1);
    sem_init(&readerSem, 0, 1);

    // Create writer threads
    for (int i = 0; i < 3; i++) {
        pthread_create(&writers[i], NULL, writer, &writerIds[i]);
    }

    // Create reader threads
    for (int i = 0; i < 5; i++) {
        pthread_create(&readers[i], NULL, reader, &readerIds[i]);
    }

    // Wait for writer threads to finish
    for (int i = 0; i < 3; i++) {
        pthread_join(writers[i], NULL);
    }

    // Wait for reader threads to finish
    for (int i = 0; i < 5; i++) {
        pthread_join(readers[i], NULL);
    }

    sem_destroy(&writerSem);
    sem_destroy(&readerSem);

    return 0;
}